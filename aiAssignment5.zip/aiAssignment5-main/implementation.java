// Implementation for ID3 here
