# aiAssignment1
1st programming assignment for AI Fall 2020
